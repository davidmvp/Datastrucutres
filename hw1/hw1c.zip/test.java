
public class test {
	public static void main(String[] args) {
	    
        Time start = new TimeMil("12:00 am");
        start.getHour();
        Time q = new TimeMil("0600");
        System.out.println("asd"+ q.getHour() + q.getMinutes());
       
      
      
}
}
