import java.util.Scanner;



public class Unique {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Set<Integer> s  = new SetArray<Integer>();
		String str = "";
		int a = 0;
		int b=0;
		System.out.println("Welcome!");
		System.out.println("Please type in the integers you want to add in the set, when you are done, please type in done");
		while (a == 0){
			str = input.next();
			if (str.equals("done")){
				a = 1;
				}
			else{
				s.add(Integer.parseInt(str));
				
			}
		}
		a = 0;
		System.out.println("Here is the list of all the integers");
		System.out.println(s.toString());
		
		Set<String> s1  = new SetArray<String>();
		System.out.println("Please type in the words you want to add in the set, when you are done, please type in done");
		while (a == 0){
			str = input.next();
			if (str.equals("done")){
				
				a = 1;
				
			}
			else{
				s1.add(str);
				
			}
		}
		System.out.println("Here is the list of all the words");
		System.out.println(s1.toString());
		System.out.println("Thank you and have a nice day");
		
}
	
}
